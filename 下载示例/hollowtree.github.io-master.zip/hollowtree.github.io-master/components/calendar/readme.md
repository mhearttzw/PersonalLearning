## 日历组件

使用方法：

1. 引用`calendar.css`文件

1. 引用`calendar.js`文件

1. 在需要显示日历的位置添加一个div，并使其类名为`calendar`，id任意（如`box`）

1. 在js中添加`calendar("box");`

