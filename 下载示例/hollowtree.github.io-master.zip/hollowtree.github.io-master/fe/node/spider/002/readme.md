### node 爬虫

1. `npm install`

1. `node app.js`

demo: [Link](http://www.smalltree.xyz/node/spider/002)
