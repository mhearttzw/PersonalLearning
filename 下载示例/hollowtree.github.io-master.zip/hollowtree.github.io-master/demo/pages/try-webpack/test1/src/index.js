var el = require('./hello-world.js');
document.body.appendChild(el());
require('./hello-world.css');
require('./hello-world.less');
require('./hello-world.styl');