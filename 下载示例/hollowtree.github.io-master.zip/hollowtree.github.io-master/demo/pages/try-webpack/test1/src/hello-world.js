module.exports = function() {
    var el=document.createElement("h1");
    el.innerHTML="Hello World!";
    return el;
}