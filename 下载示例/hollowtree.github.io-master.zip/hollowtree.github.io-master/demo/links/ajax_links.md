##一些 Ajax 实践

<p style="color:red;">网页都放在 VPS 上，VPS性能不是很好。如果链接访问不了，可能需要翻墙。</p>

点击链接时可以同时按住 Ctrl 键，以便在新标签页打开网页。

demo 001: [论语十则](http://smalltree.xyz/ajax/001/index.html)
